create definer = root@localhost trigger provider_update_trigger
    after update
    on providers
    for each row
BEGIN
    UPDATE users
    SET email = NEW.email, password = NEW.password
    WHERE provider_id = OLD.id;
END;

