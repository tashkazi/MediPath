create definer = root@localhost trigger update_provider_in_users
    after update
    on providers
    for each row
BEGIN
    UPDATE users
    SET email = NEW.email, password = NEW.password
    WHERE userType = 'provider' AND id = NEW.id;
END;

