create definer = root@localhost trigger patient_insert_trigger
    after insert
    on patients
    for each row
BEGIN
    INSERT INTO users (email, password, patient_id, userType)
    VALUES (NEW.email, NEW.password, NEW.id, 'patient');
END;

