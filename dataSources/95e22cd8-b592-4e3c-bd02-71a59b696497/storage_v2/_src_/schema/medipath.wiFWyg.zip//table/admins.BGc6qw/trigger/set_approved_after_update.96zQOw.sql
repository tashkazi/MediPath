create definer = root@localhost trigger set_approved_after_update
    after update
    on admins
    for each row
BEGIN
    IF NEW.approved = 'booked' THEN
        UPDATE admins SET approved = 'approved' WHERE id = NEW.id;
    END IF;
END;

