create definer = root@localhost trigger admin_update_trigger
    after update
    on admins
    for each row
BEGIN
    UPDATE users
    SET email = NEW.email, password = NEW.password
    WHERE admin_id = OLD.id;
END;

