create definer = root@localhost trigger patient_update_trigger
    after update
    on patients
    for each row
BEGIN
    UPDATE users
    SET email = NEW.email, password = NEW.password
    WHERE patient_id = OLD.id;
END;

