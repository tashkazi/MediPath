create definer = doadmin@`%` trigger delete_patient_trigger
    after delete
    on patients
    for each row
BEGIN
    DELETE FROM users WHERE patient_id = OLD.id;
END;

