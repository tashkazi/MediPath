create definer = doadmin@`%` trigger delete_patient_appointments_trigger
    after delete
    on patients
    for each row
BEGIN
    DELETE FROM appointments WHERE patient_id = OLD.id;
END;

