create definer = root@localhost trigger delete_appointments_after_users_delete
    after delete
    on users
    for each row
BEGIN
    DELETE FROM appointments
    WHERE provider_id = OLD.id OR patient_id = OLD.id OR admin_id = OLD.id;
END;

