create
    definer = root@localhost procedure InsertOrUpdateUser(IN email_param varchar(255), IN password_param varchar(255),
                                                          IN admin_id_param int)
BEGIN
    DECLARE existing_user_id INT;
    
    -- Check if there's an existing entry in the users table for the given email
    SELECT id INTO existing_user_id FROM users WHERE email = email_param;

    IF existing_user_id IS NULL THEN
        -- No existing entry, so insert a new one
        INSERT INTO users (email, password, admin_id, userType)
        VALUES (email_param, password_param, admin_id_param, 'admin');
    ELSE
        -- Update the existing entry with the new admin_id
        UPDATE users SET admin_id = admin_id_param WHERE id = existing_user_id;
    END IF;
END;

