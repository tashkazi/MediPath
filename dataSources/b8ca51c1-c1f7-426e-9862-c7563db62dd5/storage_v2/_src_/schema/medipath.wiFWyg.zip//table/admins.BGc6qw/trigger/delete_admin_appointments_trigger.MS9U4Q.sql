create definer = doadmin@`%` trigger delete_admin_appointments_trigger
    after delete
    on admins
    for each row
BEGIN
    DELETE FROM appointments WHERE admin_id = OLD.id;
END;

