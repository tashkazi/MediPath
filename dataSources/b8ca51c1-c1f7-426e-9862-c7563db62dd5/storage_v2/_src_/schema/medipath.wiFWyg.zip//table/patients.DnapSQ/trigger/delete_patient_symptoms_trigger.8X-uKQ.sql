create definer = doadmin@`%` trigger delete_patient_symptoms_trigger
    after delete
    on patients
    for each row
BEGIN
    DELETE FROM symptoms WHERE patient_id = OLD.id;
END;

