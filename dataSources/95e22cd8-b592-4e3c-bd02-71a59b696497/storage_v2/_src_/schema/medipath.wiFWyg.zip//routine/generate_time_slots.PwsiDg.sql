create
    definer = root@localhost procedure generate_time_slots(IN provider_id int, IN start_date date, IN end_date date)
BEGIN
    SET @current_date = start_date;

    WHILE @current_date <= end_date DO
        SET @current_time = '09:00:00'; -- Start time
        
        WHILE @current_time < '18:00:00' DO -- End time
            -- Check if the time slot already exists
            IF NOT EXISTS (
                SELECT * FROM appointments
                WHERE provider_id = provider_id
                AND appointment_date = @current_date
                AND start_time = @current_time
            ) THEN
                INSERT INTO appointments (provider_id, appointment_date, start_time, end_time, status)
                VALUES (provider_id, @current_date, @current_time, ADDTIME(@current_time, '00:15:00'), 'Available'); -- Assuming 15-minute time slots
            END IF;
            
            SET @current_time = ADDTIME(@current_time, '00:15:00'); -- Increment time by 15 minutes
        END WHILE;
        
        SET @current_date = ADDDATE(@current_date, 1); -- Move to the next date
    END WHILE;
END;

