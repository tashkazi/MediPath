create definer = root@localhost trigger admin_insert_trigger
    after insert
    on admins
    for each row
BEGIN
    INSERT INTO users (email, password, admin_id, userType)
    VALUES (NEW.email, NEW.password, NEW.id, 'admin');
END;

