create definer = root@localhost trigger add_provider_to_users
    after insert
    on providers
    for each row
BEGIN
    INSERT INTO users (email, password, userType)
    VALUES (NEW.email, NEW.password, 'provider');
END;

