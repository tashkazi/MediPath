create definer = doadmin@`%` trigger update_patient_trigger
    after update
    on patients
    for each row
BEGIN
    UPDATE users 
    SET email = NEW.email, password = NEW.password
    WHERE patient_id = NEW.id;
END;

