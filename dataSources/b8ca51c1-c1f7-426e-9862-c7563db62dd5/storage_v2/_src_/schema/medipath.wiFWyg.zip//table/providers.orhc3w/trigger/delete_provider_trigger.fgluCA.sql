create definer = doadmin@`%` trigger delete_provider_trigger
    after delete
    on providers
    for each row
BEGIN
    DELETE FROM users WHERE provider_id = OLD.id;
END;

