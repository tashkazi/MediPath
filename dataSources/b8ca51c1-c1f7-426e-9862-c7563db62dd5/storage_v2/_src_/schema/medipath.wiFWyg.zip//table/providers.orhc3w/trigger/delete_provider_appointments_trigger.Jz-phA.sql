create definer = doadmin@`%` trigger delete_provider_appointments_trigger
    after delete
    on providers
    for each row
BEGIN
    DELETE FROM appointments WHERE provider_id = OLD.id;
END;

