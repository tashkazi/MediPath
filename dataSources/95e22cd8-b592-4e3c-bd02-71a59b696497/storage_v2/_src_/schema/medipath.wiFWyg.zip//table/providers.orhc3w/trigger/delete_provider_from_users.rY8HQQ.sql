create definer = root@localhost trigger delete_provider_from_users
    after delete
    on providers
    for each row
BEGIN
    DELETE FROM users
    WHERE userType = 'provider' AND id = OLD.id;
END;

