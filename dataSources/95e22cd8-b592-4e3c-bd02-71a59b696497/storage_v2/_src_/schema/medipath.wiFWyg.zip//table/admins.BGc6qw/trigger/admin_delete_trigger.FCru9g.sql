create definer = root@localhost trigger admin_delete_trigger
    after delete
    on admins
    for each row
BEGIN
    DELETE FROM users WHERE admin_id = OLD.id;
END;

