create definer = doadmin@`%` trigger delete_provider_symptoms_trigger
    after delete
    on providers
    for each row
BEGIN
    DELETE FROM symptoms WHERE provider_id = OLD.id;
END;

