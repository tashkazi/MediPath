create definer = doadmin@`%` trigger update_provider_trigger
    after update
    on providers
    for each row
BEGIN
    UPDATE users 
    SET email = NEW.email, password = NEW.password
    WHERE provider_id = NEW.id;
END;

