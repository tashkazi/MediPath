create definer = doadmin@`%` trigger delete_admin_symptoms_trigger
    after delete
    on admins
    for each row
BEGIN
    DELETE FROM symptoms WHERE patient_id IN (SELECT id FROM patients WHERE admin_id = OLD.id);
END;

