create definer = root@localhost trigger provider_insert_trigger
    after insert
    on providers
    for each row
BEGIN
    INSERT INTO users (email, password, provider_id, userType)
    VALUES (NEW.email, NEW.password, NEW.id, 'provider');
END;

