create definer = root@localhost trigger after_delete_admins
    after delete
    on admins
    for each row
BEGIN
    DELETE FROM users WHERE id = OLD.id;
END;

